package cp213;

import java.time.LocalDate;

/**
 * Student class definition.
 *
 * @author your name here
 * @version 2022-01-17
 */
public class Student implements Comparable<Student> {

    // Attributes
    private LocalDate birthDate = null;
    private String forename = "";
    private int id = 0;
    private String surname = "";

    /**
     * Instantiates a Student object.
     *
     * @param id        student ID number
     * @param surname   student surname
     * @param forename  name of forename
     * @param birthDate birthDate in 'YYYY-MM-DD' format
     */
    public Student(int id, String surname, String forename, LocalDate birthDate) {

	// assign attributes here
	this.id = id;
	this.surname = surname;
	this.forename = forename;
	this.birthDate = birthDate;

	return;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString() Creates a formatted string of student data.
     */
    @Override
    public String toString() {
	    // The exact format expected: ensure proper indentation and alignment
	    return String.format("Name:      %s, %s\nID:        %d\nBirthdate: %s", 
	        this.surname, this.forename, this.id, this.birthDate);
	}

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(final Student other) {
	// int result = 0;

	// your code here
	return Integer.compare(this.id, other.id);

	// return result;
    }

    // getters and setters defined here
    public LocalDate getBirthDate() {
	return birthDate;
    }

    public String getForename() {
	return forename;
    }

    public int getId() {
	return id;
    }

    public String getSurname() {
	return surname;
    }

    public void setId(int id) {
	this.id = id;
    }

    public void setSurname(String surname) {
	this.surname = surname;
    }

    public void setForename(String forename) {
	this.forename = forename;
    }

    public void setBirthDate(LocalDate birthDate) {
	this.birthDate = birthDate;
    }
}
