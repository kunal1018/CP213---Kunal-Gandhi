package cp213;

import java.util.Scanner;

/**
 * Class to demonstrate the use of Scanner with a keyboard and File objects.
 *
 * @author Kunal Gandhi
 * @version 2024-09-17
 */
public class ScannerTest {

    /**
     * Count lines in the scanned file.
     *
     * @param source Scanner to process (file or string to read lines from)
     * @return number of lines in the scanned file
     */
    public static int countLines(final Scanner source) {
        int count = 0;

        // While there are more lines in the file
        while (source.hasNextLine()) {
            source.nextLine();  // Read the next line
            count++;  // Increment the line count
        }

        return count;
    }

    /**
     * Count tokens in the scanned object.
     *
     * @param source Scanner to process (file or string to read tokens from)
     * @return number of tokens in the scanned object
     */
    public static int countTokens(final Scanner source) {
        int tokens = 0;

        // While there are more tokens to read
        while (source.hasNext()) {
            source.next();  // Read the next token
            tokens++;  // Increment the token count
        }

        return tokens;
    }

    /**
     * Ask for and total integers from the keyboard.
     *
     * @param keyboard Scanner to process user input from the keyboard
     * @return total of positive integers entered from the keyboard
     */
    public static int readNumbers(final Scanner keyboard) {
        int total = 0;

        // Keep reading input until the user enters 'q'
        while (keyboard.hasNext()) {
            if (keyboard.hasNextInt()) {  // If the input is an integer
                int number = keyboard.nextInt();  // Read the integer
                total += number;  // Add the number to the total
            } else {
                String input = keyboard.next();  // Read the input as a string
                if (input.equals("q")) {  // If the input is 'q', quit
                    break;
                } else {
                    System.out.println("'" + input + "' is not an integer or 'q'.");
                }
            }
        }

        return total;
    }
}

