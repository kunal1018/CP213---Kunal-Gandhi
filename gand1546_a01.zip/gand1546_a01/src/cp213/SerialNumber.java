package cp213;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * @author Your name and id here
 * @version 2024-09-01
 */
public class SerialNumber {

    /**
     * Determines if a string contains all digits.
     *
     * @param str The string to test.
     * @return true if str is all digits, false otherwise.
     */
    public static boolean allDigits(final String str) {

        // Iterate over the string and check if all characters are digits
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                return false; // Found a non-digit character
            }
        }
        return true; // All characters are digits
    }

    /**
     * Determines if a string is a good serial number. Good serial numbers are of
     * the form 'SN/nnnn-nnn', where 'n' is a digit.
     *
     * @param sn The serial number to test.
     * @return true if the serial number is valid in form, false otherwise.
     */
    public static boolean validSn(final String sn) {

        // Check if the length is exactly 11 characters for the format 'SN/nnnn-nnn'
        if (sn.length() != 11) {
            return false;
        }

        // Check if the string starts with 'SN/'
        if (!sn.startsWith("SN/")) {
            return false;
        }

        // Check if the characters after 'SN/' are digits (positions 3 to 6 and 8 to 10)
        String firstPart = sn.substring(3, 7); // Extract nnnn part
        String secondPart = sn.substring(8, 11); // Extract nnn part

        // Ensure that character at position 7 is '-'
        if (sn.charAt(7) != '-') {
            return false;
        }

        // Use the allDigits method to check the digit parts
        return allDigits(firstPart) && allDigits(secondPart);
    }


    /**
     * Evaluates serial numbers from a file. Writes valid serial numbers to
     * good_sns, and invalid serial numbers to bad_sns. Each line of fileIn contains
     * a (possibly valid) serial number.
     *
     * @param fileIn  a file already open for reading
     * @param goodSns a file already open for writing
     * @param badSns  a file already open for writing
     */
    public static void validSnFile(final Scanner fileIn, final PrintStream goodSns, final PrintStream badSns) {

        while (fileIn.hasNextLine()) {
            String serialNumber = fileIn.nextLine();
            // Check if the serial number is valid
            if (validSn(serialNumber)) {
                goodSns.println(serialNumber); // Write valid serial number to goodSns
            } else {
                badSns.println(serialNumber); // Write invalid serial number to badSns
            }
        }
    }
}
