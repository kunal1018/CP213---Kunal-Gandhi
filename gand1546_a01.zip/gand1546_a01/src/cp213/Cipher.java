package cp213;

/**
 * @author Your name and id here
 * @version 2024-09-01
 */
public class Cipher {
    // Constants
    public static final String ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final int ALPHA_LENGTH = ALPHA.length();

    /**
     * Encipher a string using a shift cipher. Each letter is replaced by a letter
     * 'n' letters to the right of the original. Thus for example, all shift values
     * evenly divisible by 26 (the length of the English alphabet) replace a letter
     * with itself. Non-letters are left unchanged.
     *
     * @param s string to encipher
     * @param n the number of letters to shift
     * @return the enciphered string in all upper-case
     */
    public static String shift(final String s, final int n) {

        StringBuilder result = new StringBuilder();
        int shift = n % ALPHA_LENGTH; // Handle shifts larger than the alphabet length

        for (char ch : s.toUpperCase().toCharArray()) {
            if (Character.isLetter(ch)) {
                // Find the position in the alphabet
                int originalPos = ALPHA.indexOf(ch);
                // Calculate new position with the shift
                int newPos = (originalPos + shift) % ALPHA_LENGTH;
                if (newPos < 0) {
                    newPos += ALPHA_LENGTH; // Handle negative shifts
                }
                // Append the shifted letter
                result.append(ALPHA.charAt(newPos));
            } else {
                // Non-letter characters are appended unchanged
                result.append(ch);
            }
        }
        // Return the enciphered string
        return result.toString();
    }

    /**
     * Encipher a string using the letter positions in ciphertext. Each letter is
     * replaced by the letter in the same ordinal position in the ciphertext.
     * Non-letters are left unchanged.
     *
     * <pre>
    Alphabet:   ABCDEFGHIJKLMNOPQRSTUVWXYZ
    Ciphertext: AVIBROWNZCEFGHJKLMPQSTUXYD
     * </pre>
     *
     * A is replaced by A, B by V, C by I, D by B, E by R, and so on. Non-letters
     * are ignored.
     *
     * @param s          string to encipher
     * @param ciphertext ciphertext alphabet
     * @return the enciphered string in all upper-case
     */
    public static String substitute(final String s, final String ciphertext) {

        StringBuilder result = new StringBuilder();
        String upperS = s.toUpperCase();
        String upperCiphertext = ciphertext.toUpperCase();

        for (char ch : upperS.toCharArray()) {
            if (Character.isLetter(ch)) {
                // Find the position of the character in the ALPHA string
                int originalPos = ALPHA.indexOf(ch);
                // Substitute with the corresponding character in the ciphertext
                result.append(upperCiphertext.charAt(originalPos));
            } else {
                // Non-letter characters are appended unchanged
                result.append(ch);
            }
        }
        // Return the enciphered string
        return result.toString();
    }
}


