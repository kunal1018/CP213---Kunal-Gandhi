package cp213;

/**
 * Inherited class in simple example of inheritance / polymorphism.
 *
 * @author Kunal Gandhi
 * @version 2024-10-30
 */
public class CAS extends Professor {
    private String term;

    /**
     * Constructs a CAS with the given name, department, and term.
     * 
     * @param lastName CAS last name (surname)
     * @param firstName CAS first name (given name)
     * @param department CAS department
     * @param term CAS term in the format YYYYTT
     */
    public CAS(String lastName, String firstName, String department, String term) {
        super(lastName, firstName, department);
        this.term = term;
    }

    /**
     * Getter for term.
     * 
     * @return this.term
     */
    public String getTerm() {
        return this.term;
    }

    /**
     * Creates formatted string version of CAS.
     */
    @Override
    public String toString() {
        return super.toString() + "\nTerm: " + this.term;
    }
}